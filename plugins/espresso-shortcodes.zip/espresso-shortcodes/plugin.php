<?php
/*
Plugin Name: ESPRESSO Shortcodes
Plugin URI: http://envirra.com
Description: Shortcodes for ESPRESSO Theme
Version: 1.0.0
Author: Envirra
Author URI: http://envirra.com
*/

if ( ! defined( 'VW_CONST_ENABLE_SHORTCODES' ) ) define( 'VW_CONST_ENABLE_SHORTCODES', true );

/**
 * Register shortcodes
 */
add_action( 'after_setup_theme', 'vw_register_shortcodes' );
if ( ! function_exists( 'vw_register_shortcodes' ) ) {
	function vw_register_shortcodes() {
		add_shortcode( '404', 'vw_shortcode_404' );
		add_shortcode( 'author', 'vw_shortcode_author' );
		add_shortcode( 'accordions', 'vw_shortcode_accordions' );
		add_shortcode( 'accordion', 'vw_shortcode_accordion' );
		add_shortcode( 'button', 'vw_shortcode_button' );
		add_shortcode( 'row', 'vw_shortcode_row' );
		add_shortcode( 'column', 'vw_shortcode_column' );
		add_shortcode( 'customfont1', 'vw_shortcode_custom_font_1' );
		add_shortcode( 'customfont2', 'vw_shortcode_custom_font_2' );
		add_shortcode( 'dropcap', 'vw_shortcode_dropcap' );
		add_shortcode( 'em', 'vw_shortcode_emphasize' );
		add_shortcode( 'gap', 'vw_shortcode_gap' );
		add_shortcode( 'headline', 'vw_shortcode_headline' );
		add_shortcode( 'image', 'vw_shortcode_image' );
		add_shortcode( 'infobox', 'vw_shortcode_infobox' );
		add_shortcode( 'list', 'vw_shortcode_list' );
		add_shortcode( 'list_item', 'vw_shortcode_list_item' );
		add_shortcode( 'logo', 'vw_shortcode_logo' );
		add_shortcode( 'map', 'flexmap_show_map' );
		add_shortcode( 'mark', 'vw_shortcode_mark' );
		add_shortcode( 'posts', 'vw_shortcode_posts' );
		add_shortcode( 'pricing_table', 'vw_shortcode_pricing_table' );
		add_shortcode( 'pricing_item', 'vw_shortcode_pricing_item' );
		add_shortcode( 'quote', 'vw_shortcode_quote' );
		add_shortcode( 'site_social_icons', 'vw_shortcode_site_social_icons' );
		add_shortcode( 'tabs', 'vw_shortcode_tabs' );
		add_shortcode( 'tab', 'vw_shortcode_tab_item' );
		add_shortcode( 'title', 'vw_shortcode_title' );

		// Register shortcode for custom sidebar
		if ( ! defined( 'VW_CONST_DISABLE_SMK_SIDEBAR_SHORTCODE_FIX' ) ) {
			remove_shortcode( 'smk_sidebar' );
			add_shortcode( 'smk_sidebar', 'vw_smk_sidebar_shortcode' );
		}
		add_shortcode( 'sidebar', 'vw_smk_sidebar_shortcode' );

		// Register Like shortcode
		if ( function_exists( 'vwplk_like_shortcode' ) ) {
			add_shortcode( 'post_likes', 'vwplk_like_shortcode' );
		}

		// Register Review shortcode
		if ( function_exists( 'vwrev_review_shortcode' ) ) {
			add_shortcode( 'review', 'vwrev_review_shortcode' );
		}

		// Register Review shortcode
		if ( function_exists( 'vwrev_review_shortcode' ) ) {
			add_shortcode( 'review', 'vwrev_review_shortcode' );
		}
	}
}

/**
 * Load shortcode editor
 */
if ( is_admin() ) {
	require_once 'shortcode-editor/shortcode-editor.php';
}