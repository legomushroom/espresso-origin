<?php
/**
 * X-Plugin Name: Meta Box
 * X-Plugin URI: https://metabox.io
 * X-Description: Create custom meta boxes and custom fields for any post type in WordPress.
 * X-Version: 4.9.8
 * X-Author: Rilwis
 * X-Author URI: http://www.deluxeblogtips.com
 * X-License: GPL2+
 * X-Text Domain: meta-box
 * X-Domain Path: /languages/
 */

if ( defined( 'ABSPATH' ) && ! defined( 'RWMB_VER' ) ) {
	require_once dirname( __FILE__ ) . '/inc/loader.php';
	$loader = new RWMB_Loader;
	$loader->init();
}
